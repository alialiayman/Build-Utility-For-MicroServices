﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CVBuild
{
    public partial class Form1 : Form
    {
        List<string> allSolutions = new List<string>();
        List<string> allimpServices = new List<string>();
        IMPServices impServicesManager = new IMPServices();
        public Form1()
        {
            InitializeComponent();
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            allimpServices = impServicesManager.GetImpServices();
            lstiMPServices.DataSource = allimpServices;
            lblimpServices.Text = "iMP Services " + lstiMPServices.Items.Count;
            if (!string.IsNullOrEmpty(dfsBranch.Text))
            {
                LoadAllSolutions();
                if (File.Exists("Services.txt"))
                 lstRestartServices.DataSource=  File.ReadAllLines("Services.txt");
                if (File.Exists("Solutions.txt"))
                    lstSolutionsToBuild.DataSource = File.ReadAllLines("Solutions.txt");
            }
        }

        
        private void LoadAllSolutions()
        {
            try
            {
                var solutions = Directory.GetFiles(dfsBranch.Text, "*.sln", SearchOption.AllDirectories);
                foreach (var item in solutions)
                {
                    allSolutions.Add(item);
                    var index = lstSolutions.Items.Add(item);
                }
            }
            catch { }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.Save();
        }

        private void StopSelectedServices()
        {
            var sw = new Stopwatch();
            sw.Start();
            DisplayMessage("Stopping " + lstRestartServices.Items.Count + " services in parallel");
            var servicesToStop = new List<string>();
            foreach (var item in lstRestartServices.Items)
            {
                servicesToStop.Add(item.ToString());
            }
            var stoppedServices = impServicesManager.StopServices(servicesToStop);
            DisplayMessage(lstRestartServices.Items.Count + " services stopped in " + sw.Elapsed.TotalMilliseconds / 1000 + " sec");
        }

        private void DisplayMessage(string message)
        {
            this.Invoke((MethodInvoker)delegate
            {
                sbMessage.Text = message;
            });

        }

        private void StartSelectedServices()
        {
            var sw = new Stopwatch();
            sw.Start();
            DisplayMessage("Starting " + lstRestartServices.Items.Count + " services in parallel");
            var servicesToStart = new List<string>();
            foreach (var item in lstRestartServices.Items)
            {
                servicesToStart.Add(item.ToString());
            }
            var startedServices = impServicesManager.StartServices(servicesToStart);
            DisplayMessage(lstRestartServices.Items.Count + " services started in " + sw.Elapsed.TotalMilliseconds / 1000 + " sec");

        }


        private void btnBuild_Click(object sender, EventArgs e)
        {
            StopSelectedServices();
            List<Process> ps = new List<Process>();
            foreach (var item in lstSolutionsToBuild.SelectedItems)
            {

                var slnName = Path.GetFileNameWithoutExtension(item.ToString());
                var batchCommand = "title " + slnName + Environment.NewLine;
                foreach (var svcName in lstRestartServices.Items)
                {
                    batchCommand += "net stop " + svcName.ToString() + Environment.NewLine;
                }
                batchCommand += "\"C:\\Program Files (x86)\\Microsoft Visual Studio\\2017\\Community\\MSBuild\\15.0\\Bin\\msbuild.exe\" ";
                batchCommand += item.ToString() + " /p:Configuration=Debug /p:Platform=\"Any CPU\" /t:build /maxcpucount:4 /fl /flp:logfile="+ slnName  + ".log;verbosity=minimal /clp:Summary;ShowEventId;verbosity=minimal";
                batchCommand += Environment.NewLine + "Timeout /T 30";
                var batchFileName = slnName + ".bat";
                File.WriteAllText(batchFileName, batchCommand);
                ps.Add( Process.Start(batchFileName));
            }
            foreach (var p in ps)
            {
                p.WaitForExit();
            }
            StartSelectedServices();

        }

        private void dfsSearch_TextChanged(object sender, EventArgs e)
        {
            lstSolutions.DataSource = allSolutions.Where(x => x.ToLower().Contains(dfsSearch.Text.ToLower())).ToList();

        }

        private void tmrServices_Tick(object sender, EventArgs e)
        {
            ServiceController[] services = ServiceController.GetServices();
            var serviceContainString = "imp.";
            // try to find service name
            foreach (ServiceController service in services)
            {
                if ((service.ServiceName.ToLower().Contains(serviceContainString) || service.DisplayName.ToLower().Contains(serviceContainString)))
                {
                    this.Invoke((MethodInvoker)delegate
                    {
                        if (service.Status == ServiceControllerStatus.Running)
                        {
                            lstiMPServices.Items.Add(service.DisplayName);
                        }
                        else
                        {
                            lstRestartServices.Items.Add(service.DisplayName);
                        }
                    });

                }

            }
        }

        private void btnAddToSolutionsToBuild_Click(object sender, EventArgs e)
        {
            foreach (var item in lstSolutions.SelectedItems)
            {
                lstSolutionsToBuild.Items.Add(item);
            }

            File.WriteAllLines("Solutions.txt", lstSolutionsToBuild.Items.Cast<string>());
        }

        private void btnRemoveFromSolutionsToBuild_Click(object sender, EventArgs e)
        {
            foreach (var item in lstSolutionsToBuild.SelectedItems)
            {
                lstSolutionsToBuild.Items.Remove(item);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var item in lstiMPServices.SelectedItems)
            {
                lstRestartServices.Items.Add(item);
            }

            File.WriteAllLines("Services.txt",lstRestartServices.Items.Cast<string>());
        }

        private void btnRemoveService_Click(object sender, EventArgs e)
        {
            foreach (var item in lstRestartServices.SelectedItems)
            {
                lstRestartServices.Items.Remove(item);
            }
        }

        private void dfsServicesFilter_TextChanged(object sender, EventArgs e)
        {
            lstiMPServices.DataSource = allimpServices.Where(x => x.ToLower().Contains(dfsServicesFilter.Text.ToLower())).ToList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StopSelectedServices();
            
            foreach (var sln in lstSolutionsToBuild.Items)
            {
                var slnName = Path.GetFileNameWithoutExtension(sln.ToString());
                var batchCommand = "title " + slnName + Environment.NewLine;
                foreach (var svcName in lstRestartServices.Items)
                {
                    batchCommand += "net stop " + svcName.ToString() + Environment.NewLine;
                }
                batchCommand += "\"C:\\Program Files (x86)\\Microsoft Visual Studio\\2017\\Community\\MSBuild\\15.0\\Bin\\msbuild.exe\" ";
                batchCommand += sln.ToString() + " /p:Configuration=Debug /p:Platform=\"Any CPU\" /t:build /maxcpucount:4 /fl /flp:logfile=" + slnName + DateTime.Now.Ticks.ToString()  + ".log;verbosity=minimal /clp:Summary;ShowEventId;verbosity=minimal";
                batchCommand += Environment.NewLine + "Timeout /T 30";
                var batchFileName = slnName + ".bat";
                File.WriteAllText(batchFileName, batchCommand);
                Process.Start(batchFileName);
            }
            
        }

        private void btnStartSelectedServices_Click(object sender, EventArgs e)
        {
            var sw = new Stopwatch();
            sw.Start();
            sbMessage.Text = "Starting " + lstRestartServices.Items.Count + " services in parallel";
            btnStartSelectedServices.Visible = false;
            StartSelectedServices();
            btnStartSelectedServices.Visible = true;
            sbMessage.Text =  lstRestartServices.Items.Count + " services started in " + sw.Elapsed.TotalMilliseconds/1000  + " sec";
        }
    }
}
