﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace CVBuild
{
    public class IMPServices
    {
        List<string> Services = new List<string>();

        public List<string> GetImpServices()
        {
            if (Services.Any())
                return Services;

            Services = ServiceController.GetServices().Where(x=> x.DisplayName.ToLower().StartsWith("imp.")).Select(a=> a.DisplayName).ToList();
            return Services;
        }

        public List<string> StopServices (List<string> input)
        {
            var stoppedServices = new List<string>();
            var servicesToStop = ServiceController.GetServices().Where(x=> input.Contains(x.ServiceName)).ToList();
            foreach (var service in servicesToStop)
            {
                if (service.Status == ServiceControllerStatus.Running && service.CanStop)
                {
                    service.WaitForStatus(ServiceControllerStatus.Running);
                    service.Stop();
                }
            }

            foreach (var service in servicesToStop)
            {

                    service.WaitForStatus(ServiceControllerStatus.Stopped);
                    stoppedServices.Add(service.DisplayName);
                
            }

            return stoppedServices;
        }

        public List<string> StartServices(List<string> input)
        {
            var startedServices = new List<string>();
            var servicesToStart = ServiceController.GetServices().Where(x => input.Contains(x.ServiceName)).ToList();
            foreach (ServiceController service in servicesToStart)
            {

                if (service.Status == ServiceControllerStatus.Stopped)
                {
                    service.Start();
                }
                
            }

            foreach (ServiceController service in servicesToStart)
            {
                if (service.Status == ServiceControllerStatus.Stopped)
                {
                    service.WaitForStatus(ServiceControllerStatus.Running);
                    startedServices.Add(service.DisplayName);
                }
            }

            return startedServices;
        }
    }
}
