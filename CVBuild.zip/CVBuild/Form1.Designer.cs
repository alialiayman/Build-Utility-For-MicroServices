﻿namespace CVBuild
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBuild = new System.Windows.Forms.Button();
            this.lstSolutions = new System.Windows.Forms.ListBox();
            this.dfsSearch = new System.Windows.Forms.TextBox();
            this.dfsBranch = new System.Windows.Forms.TextBox();
            this.lstiMPServices = new System.Windows.Forms.ListBox();
            this.lstRestartServices = new System.Windows.Forms.ListBox();
            this.tmrServices = new System.Windows.Forms.Timer(this.components);
            this.lstSolutionsToBuild = new System.Windows.Forms.ListBox();
            this.btnAddToSolutionsToBuild = new System.Windows.Forms.Button();
            this.lblimpServices = new System.Windows.Forms.Label();
            this.btnAddService = new System.Windows.Forms.Button();
            this.btnBuildAllSolutionsToBuild = new System.Windows.Forms.Button();
            this.dfsServicesFilter = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnRemoveFromSolutionsToBuild = new System.Windows.Forms.Button();
            this.btnRemoveService = new System.Windows.Forms.Button();
            this.btnStartSelectedServices = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.sbMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Branch";
            // 
            // btnBuild
            // 
            this.btnBuild.Location = new System.Drawing.Point(15, 423);
            this.btnBuild.Name = "btnBuild";
            this.btnBuild.Size = new System.Drawing.Size(238, 36);
            this.btnBuild.TabIndex = 4;
            this.btnBuild.Text = "Build Selected";
            this.btnBuild.UseVisualStyleBackColor = true;
            this.btnBuild.Click += new System.EventHandler(this.btnBuild_Click);
            // 
            // lstSolutions
            // 
            this.lstSolutions.FormattingEnabled = true;
            this.lstSolutions.Location = new System.Drawing.Point(15, 114);
            this.lstSolutions.Name = "lstSolutions";
            this.lstSolutions.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstSolutions.Size = new System.Drawing.Size(530, 134);
            this.lstSolutions.TabIndex = 7;
            // 
            // dfsSearch
            // 
            this.dfsSearch.Location = new System.Drawing.Point(390, 88);
            this.dfsSearch.Name = "dfsSearch";
            this.dfsSearch.Size = new System.Drawing.Size(152, 20);
            this.dfsSearch.TabIndex = 8;
            this.dfsSearch.TextChanged += new System.EventHandler(this.dfsSearch_TextChanged);
            // 
            // dfsBranch
            // 
            this.dfsBranch.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::CVBuild.Properties.Settings.Default, "dfsBranch", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dfsBranch.Location = new System.Drawing.Point(15, 49);
            this.dfsBranch.Name = "dfsBranch";
            this.dfsBranch.Size = new System.Drawing.Size(765, 20);
            this.dfsBranch.TabIndex = 0;
            this.dfsBranch.Text = global::CVBuild.Properties.Settings.Default.dfsBranch;
            // 
            // lstiMPServices
            // 
            this.lstiMPServices.FormattingEnabled = true;
            this.lstiMPServices.Location = new System.Drawing.Point(551, 114);
            this.lstiMPServices.Name = "lstiMPServices";
            this.lstiMPServices.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstiMPServices.Size = new System.Drawing.Size(229, 134);
            this.lstiMPServices.TabIndex = 10;
            // 
            // lstRestartServices
            // 
            this.lstRestartServices.FormattingEnabled = true;
            this.lstRestartServices.Location = new System.Drawing.Point(552, 283);
            this.lstRestartServices.Name = "lstRestartServices";
            this.lstRestartServices.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstRestartServices.Size = new System.Drawing.Size(228, 134);
            this.lstRestartServices.TabIndex = 11;
            // 
            // tmrServices
            // 
            this.tmrServices.Interval = 2000;
            this.tmrServices.Tick += new System.EventHandler(this.tmrServices_Tick);
            // 
            // lstSolutionsToBuild
            // 
            this.lstSolutionsToBuild.FormattingEnabled = true;
            this.lstSolutionsToBuild.Location = new System.Drawing.Point(15, 283);
            this.lstSolutionsToBuild.Name = "lstSolutionsToBuild";
            this.lstSolutionsToBuild.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstSolutionsToBuild.Size = new System.Drawing.Size(530, 134);
            this.lstSolutionsToBuild.TabIndex = 14;
            // 
            // btnAddToSolutionsToBuild
            // 
            this.btnAddToSolutionsToBuild.BackColor = System.Drawing.Color.LimeGreen;
            this.btnAddToSolutionsToBuild.Location = new System.Drawing.Point(510, 254);
            this.btnAddToSolutionsToBuild.Name = "btnAddToSolutionsToBuild";
            this.btnAddToSolutionsToBuild.Size = new System.Drawing.Size(35, 23);
            this.btnAddToSolutionsToBuild.TabIndex = 15;
            this.btnAddToSolutionsToBuild.Text = "Add";
            this.btnAddToSolutionsToBuild.UseVisualStyleBackColor = false;
            this.btnAddToSolutionsToBuild.Click += new System.EventHandler(this.btnAddToSolutionsToBuild_Click);
            // 
            // lblimpServices
            // 
            this.lblimpServices.AutoSize = true;
            this.lblimpServices.Location = new System.Drawing.Point(548, 96);
            this.lblimpServices.Name = "lblimpServices";
            this.lblimpServices.Size = new System.Drawing.Size(69, 13);
            this.lblimpServices.TabIndex = 16;
            this.lblimpServices.Text = "iMP Services";
            // 
            // btnAddService
            // 
            this.btnAddService.BackColor = System.Drawing.Color.LimeGreen;
            this.btnAddService.Location = new System.Drawing.Point(730, 254);
            this.btnAddService.Name = "btnAddService";
            this.btnAddService.Size = new System.Drawing.Size(50, 23);
            this.btnAddService.TabIndex = 17;
            this.btnAddService.Text = "Add";
            this.btnAddService.UseVisualStyleBackColor = false;
            this.btnAddService.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBuildAllSolutionsToBuild
            // 
            this.btnBuildAllSolutionsToBuild.BackColor = System.Drawing.Color.LimeGreen;
            this.btnBuildAllSolutionsToBuild.Location = new System.Drawing.Point(307, 423);
            this.btnBuildAllSolutionsToBuild.Name = "btnBuildAllSolutionsToBuild";
            this.btnBuildAllSolutionsToBuild.Size = new System.Drawing.Size(238, 36);
            this.btnBuildAllSolutionsToBuild.TabIndex = 18;
            this.btnBuildAllSolutionsToBuild.Text = "Build All";
            this.btnBuildAllSolutionsToBuild.UseVisualStyleBackColor = false;
            this.btnBuildAllSolutionsToBuild.Click += new System.EventHandler(this.button2_Click);
            // 
            // dfsServicesFilter
            // 
            this.dfsServicesFilter.Location = new System.Drawing.Point(713, 89);
            this.dfsServicesFilter.Name = "dfsServicesFilter";
            this.dfsServicesFilter.Size = new System.Drawing.Size(67, 20);
            this.dfsServicesFilter.TabIndex = 20;
            this.dfsServicesFilter.TextChanged += new System.EventHandler(this.dfsServicesFilter_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Solutions";
            // 
            // btnRemoveFromSolutionsToBuild
            // 
            this.btnRemoveFromSolutionsToBuild.Location = new System.Drawing.Point(15, 254);
            this.btnRemoveFromSolutionsToBuild.Name = "btnRemoveFromSolutionsToBuild";
            this.btnRemoveFromSolutionsToBuild.Size = new System.Drawing.Size(63, 23);
            this.btnRemoveFromSolutionsToBuild.TabIndex = 22;
            this.btnRemoveFromSolutionsToBuild.Text = "Remove";
            this.btnRemoveFromSolutionsToBuild.UseVisualStyleBackColor = true;
            this.btnRemoveFromSolutionsToBuild.Click += new System.EventHandler(this.btnRemoveFromSolutionsToBuild_Click);
            // 
            // btnRemoveService
            // 
            this.btnRemoveService.Location = new System.Drawing.Point(551, 254);
            this.btnRemoveService.Name = "btnRemoveService";
            this.btnRemoveService.Size = new System.Drawing.Size(63, 23);
            this.btnRemoveService.TabIndex = 23;
            this.btnRemoveService.Text = "Remove";
            this.btnRemoveService.UseVisualStyleBackColor = true;
            this.btnRemoveService.Click += new System.EventHandler(this.btnRemoveService_Click);
            // 
            // btnStartSelectedServices
            // 
            this.btnStartSelectedServices.Location = new System.Drawing.Point(551, 423);
            this.btnStartSelectedServices.Name = "btnStartSelectedServices";
            this.btnStartSelectedServices.Size = new System.Drawing.Size(229, 36);
            this.btnStartSelectedServices.TabIndex = 24;
            this.btnStartSelectedServices.Text = "Start";
            this.btnStartSelectedServices.UseVisualStyleBackColor = true;
            this.btnStartSelectedServices.Click += new System.EventHandler(this.btnStartSelectedServices_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sbMessage});
            this.statusStrip1.Location = new System.Drawing.Point(0, 477);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(789, 22);
            this.statusStrip1.TabIndex = 25;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // sbMessage
            // 
            this.sbMessage.Name = "sbMessage";
            this.sbMessage.Size = new System.Drawing.Size(774, 17);
            this.sbMessage.Spring = true;
            this.sbMessage.Text = "Ready...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(789, 499);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btnStartSelectedServices);
            this.Controls.Add(this.btnRemoveService);
            this.Controls.Add(this.btnRemoveFromSolutionsToBuild);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dfsServicesFilter);
            this.Controls.Add(this.btnBuildAllSolutionsToBuild);
            this.Controls.Add(this.btnAddService);
            this.Controls.Add(this.btnBuild);
            this.Controls.Add(this.lblimpServices);
            this.Controls.Add(this.btnAddToSolutionsToBuild);
            this.Controls.Add(this.lstSolutionsToBuild);
            this.Controls.Add(this.lstRestartServices);
            this.Controls.Add(this.lstiMPServices);
            this.Controls.Add(this.dfsSearch);
            this.Controls.Add(this.lstSolutions);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dfsBranch);
            this.Name = "Form1";
            this.Text = "iMP Build";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox dfsBranch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBuild;
        private System.Windows.Forms.ListBox lstSolutions;
        private System.Windows.Forms.TextBox dfsSearch;
        private System.Windows.Forms.ListBox lstiMPServices;
        private System.Windows.Forms.ListBox lstRestartServices;
        private System.Windows.Forms.Timer tmrServices;
        private System.Windows.Forms.ListBox lstSolutionsToBuild;
        private System.Windows.Forms.Button btnAddToSolutionsToBuild;
        private System.Windows.Forms.Label lblimpServices;
        private System.Windows.Forms.Button btnAddService;
        private System.Windows.Forms.Button btnBuildAllSolutionsToBuild;
        private System.Windows.Forms.TextBox dfsServicesFilter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnRemoveFromSolutionsToBuild;
        private System.Windows.Forms.Button btnRemoveService;
        private System.Windows.Forms.Button btnStartSelectedServices;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel sbMessage;
    }
}

